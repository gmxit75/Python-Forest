import pygame
import sys

pygame.init()
Largura = 1440
Altura = 810

pygame.mixer.music.load("musica.mp3")
pygame.mixer.music.play(-1)


acerto = pygame.mixer.Sound("acerto01.mp3")
erro02 = pygame.mixer.Sound("erro0101.mp3")
levelup = pygame.mixer.Sound("level.mp3")

icon = pygame.image.load("iconemato.png")  # Substitua 'icone.png' pelo caminho do seu ícone
pygame.display.set_icon(icon)
global ponto
ponto = 0

global acerto1
acerto1 = 0

global acerto2
acerto2 = 0

global acerto3
acerto3 = 0

global acerto4
acerto4 = 0

global acerto5
acerto5 = 0

global acerto6
acerto6 = 0


def janela1():

    janela1 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("inicio0202.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela1.blit(imagem, (0, 0))

    global ponto
    botao1_img = pygame.image.load("play02.png")
    botao1_pos = pygame.Rect(420, 260, 600, 300)
    

    botao2_img = pygame.image.load("somon.png")
    botao2_pos = pygame.Rect (1300, 730, 100, 100)
    

    botao3_img = pygame.image.load("BOTAO.png")
    botao3_pos = pygame.Rect(1030, 0, 400, 100)
    
    botao4_img = pygame.image.load("sair01.png")
    botao4_pos = pygame.Rect(580, 500 , 580, 500)

    botao5_img = pygame.image.load("somoff.png")
    botao5_pos = pygame.Rect (1300, 730, 100, 100)
    

    botao1_img = pygame.transform.scale(botao1_img, (600, 300))
    botao2_img = pygame.transform.scale(botao2_img, (120, 70))
    botao3_img = pygame.transform.scale(botao3_img, (400, 100))
    botao4_img = pygame.transform.scale(botao4_img, (210, 120))
    botao5_img = pygame.transform.scale(botao5_img, (120, 70))

    janela1.blit(botao1_img, botao1_pos)
    janela1.blit(botao2_img, botao2_pos)
    janela1.blit(botao3_img, botao3_pos)
    janela1.blit(botao4_img, botao4_pos)
    janela1.blit(botao5_img, botao5_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao1_pos.collidepoint(event.pos):
                    janela100()
                                
                elif botao3_pos.collidepoint(event.pos):
                    janela_de_creditos()
               

                elif botao4_pos.collidepoint(event.pos):
                    pygame.quit()
                    sys.exit()
                
                elif botao5_pos.collidepoint(event.pos):
                    pygame.quit()
                    sys.exit()
                

                   

        pygame.display.update()

def janela999():

    janela1 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("inicio0202.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela1.blit(imagem, (0, 0))

    global ponto
    botao1_img = pygame.image.load("play02.png")
    botao1_pos = pygame.Rect(420, 260, 600, 300)
    

    botao2_img = pygame.image.load("somon.png")
    botao2_pos = pygame.Rect (1300, 730, 100, 100)
    

    botao3_img = pygame.image.load("BOTAO.png")
    botao3_pos = pygame.Rect(1030, 0, 400, 100)
    
    botao4_img = pygame.image.load("sair01.png")
    botao4_pos = pygame.Rect(580, 500 , 580, 500)

    botao5_img = pygame.image.load("somoff.png")
    botao5_pos = pygame.Rect (1300, 730, 100, 100)
    

    botao1_img = pygame.transform.scale(botao1_img, (600, 300))
    botao2_img = pygame.transform.scale(botao2_img, (120, 70))
    botao3_img = pygame.transform.scale(botao3_img, (400, 100))
    botao4_img = pygame.transform.scale(botao4_img, (210, 120))
    botao5_img = pygame.transform.scale(botao5_img, (120, 70))

    janela1.blit(botao1_img, botao1_pos)
    janela1.blit(botao2_img, botao2_pos)
    janela1.blit(botao3_img, botao3_pos)
    janela1.blit(botao4_img, botao4_pos)
    janela1.blit(botao5_img, botao5_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao1_pos.collidepoint(event.pos):
                    janela100()
     

                elif botao2_pos.collidepoint(event.pos):
                    if botao2_img == botao2_img:
                                botao2_img = botao5_img  # Alterna para a segunda imagem
                                pygame.mixer.music.unpause()  # Pausa a música
                          
                                
                elif botao3_pos.collidepoint(event.pos):
                    janela_de_creditos()
               

                elif botao4_pos.collidepoint(event.pos):
                    pygame.quit()
                    sys.exit()
                
                elif botao5_pos.collidepoint(event.pos):
                    pygame.quit()
                    sys.exit()
                

                   

        pygame.display.update()


def janela100():

    janela1 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("telafases.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela1.blit(imagem, (0, 0))

    global ponto
    global acerto1
    global acerto2
    global acerto3
    global acerto4
    global acerto5

    B = (114, 156, 107)

    global ponto
    fonte = pygame.font.Font('arial.ttf',50)
    superficie_do_numero = fonte.render(str(acerto1), True, B)
    janela1.blit(superficie_do_numero, (140, 170))

    superficie_do_numero2 = fonte.render(str(acerto2), True, B)
    janela1.blit(superficie_do_numero2, (440, 370))

    superficie_do_numero3 = fonte.render(str(acerto3), True, B)
    janela1.blit(superficie_do_numero3, (740, 170))

    superficie_do_numero4 = fonte.render(str(acerto4), True, B)
    janela1.blit(superficie_do_numero4, (1055, 370))

    superficie_do_numero5 = fonte.render(str(acerto5), True, B)
    janela1.blit(superficie_do_numero5, (1287, 170))





    botao_img = pygame.image.load("voltar02.png")
    botao_pos = pygame.Rect(22,670, 490, 400)

    botao_img = pygame.transform.scale(botao_img, (220, 130))
    
    botao1_img = pygame.image.load("rh1.png")
    botao1_pos = pygame.Rect(10, 223, 300, 163)

    botao2_img = pygame.image.load("rh3.png")
    botao2_pos = pygame.Rect (600, 223, 300, 163)
    

    botao3_img = pygame.image.load("rh2.png")
    botao3_pos = pygame.Rect(310, 424, 300, 163)
    
    botao4_img = pygame.image.load("rh4.png")
    botao4_pos = pygame.Rect(920, 424, 300, 163)

    botao5_img = pygame.image.load("rh5.png")
    botao5_pos = pygame.Rect (1140, 223, 300, 163)
    

    botao1_img = pygame.transform.scale(botao1_img, (300, 163))
    botao2_img = pygame.transform.scale(botao2_img, (300, 163))
    botao3_img = pygame.transform.scale(botao3_img, (300, 163))
    botao4_img = pygame.transform.scale(botao4_img, (300, 163))
    botao5_img = pygame.transform.scale(botao5_img, (300, 163))



    janela1.blit(botao_img, botao_pos)
    janela1.blit(botao1_img, botao1_pos)
    janela1.blit(botao2_img, botao2_pos)
    janela1.blit(botao3_img, botao3_pos)
    janela1.blit(botao4_img, botao4_pos)
    janela1.blit(botao5_img, botao5_pos)
    

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao1_pos.collidepoint(event.pos):
                    fase01()   
                elif botao2_pos.collidepoint(event.pos):
                    fase03()         

                elif botao_pos.collidepoint(event.pos):
                    janela999()        
                elif botao3_pos.collidepoint(event.pos):
                    fase02()
                elif botao4_pos.collidepoint(event.pos):
                    fase04()
                elif botao5_pos.collidepoint(event.pos):
                    fase05()
                

                   

        pygame.display.update()

def janela4():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO1.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))
    

    global ponto
    global acerto1
 

    botaoA_img = pygame.image.load("alternativa11.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)


    botaoB_img = pygame.image.load("alternativa12.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)


    botaoC_img = pygame.image.load("alternativa13.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)


    botaoD_img = pygame.image.load("alternativa14.png")
    botaoD_pos = pygame.Rect(5, 580, 740, 134)
  

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
               
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                    
                  
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()
                               

                elif botaoC_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto1 += 1
                    janela7()
                    

                    
                    #acerto
              

                elif botaoD_pos.collidepoint(event.pos):
                    erro()
                    



        pygame.display.update()


def erro():
    janela = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("telaerrou02.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela.blit(imagem, (0, 0))

    botao_img = pygame.image.load("voltar02.png")
    botao_pos = pygame.Rect(22,670, 490, 400)

    botao_img = pygame.transform.scale(botao_img, (220, 130))

    botao2_img = pygame.image.load("butonpoint.png")
    botao2_pos = pygame.Rect(1200,670, 240, 140)

    botao2_img = pygame.transform.scale(botao2_img, (240, 140))

    janela.blit(botao_img, botao_pos)
    janela.blit(botao2_img, botao2_pos)
    erro02.play()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_pos.collidepoint(event.pos):
                    janela100()
                  # Play the sound when the button is clicked
                elif botao2_pos.collidepoint(event.pos):
                    pontuacao()
                  # Play the sound when the button is clicked

        pygame.display.update()

def telafinal():
    janela = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("telafinal.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela.blit(imagem, (0, 0))

    botao_img = pygame.image.load("voltar02.png")
    botao_pos = pygame.Rect(22,670, 490, 400)

    botao_img = pygame.transform.scale(botao_img, (220, 130))

    botao2_img = pygame.image.load("butonpoint.png")
    botao2_pos = pygame.Rect(1200,670, 240, 140)

    botao2_img = pygame.transform.scale(botao2_img, (240, 140))

    janela.blit(botao2_img, botao2_pos)





    janela.blit(botao_img, botao_pos)
    levelup.play()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_pos.collidepoint(event.pos):
                    janela100()

                elif botao2_pos.collidepoint(event.pos):
                    pontuacao()


        pygame.display.update()

def pontuacao():
    janela = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("pontuação.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela.blit(imagem, (0, 0))
    BRANCO = (255, 255, 255)
    PRETO = (0, 0, 0)
    V = (0, 128, 0)
    P = (194, 204, 160)
    botao_img = pygame.image.load("voltar02.png")
    botao_pos = pygame.Rect(22,670, 490, 400)
    global ponto
    botao_img = pygame.transform.scale(botao_img, (220, 130))
    fonte = pygame.font.Font('arial.ttf',300)
    superficie_do_numero = fonte.render(str(ponto), True, P)



    janela.blit(botao_img, botao_pos)
    janela.blit(superficie_do_numero, (560, 240))




    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_pos.collidepoint(event.pos):
                    janela100()
                  # Play the sound when the button is clicked


        pygame.display.update()

def fase01():
    janela = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")
    levelup.play()
    global ponto
    global acerto1 
    acerto1 = 0
    ponto = 0

    imagem = pygame.image.load("fase01.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela.blit(imagem, (0, 0))

    botao_img = pygame.image.load("voltar.png")
    botao_pos = pygame.Rect(22,670, 490, 400)

    botao_img = pygame.transform.scale(botao_img, (220, 130))

    botao2_img = pygame.image.load("pro02.png")
    botao2_pos = pygame.Rect(1180,670, 240, 140)

    botao2_img = pygame.transform.scale(botao2_img, (250, 142))

    janela.blit(botao_img, botao_pos)
    janela.blit(botao2_img, botao2_pos)
    

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_pos.collidepoint(event.pos):
                    janela100()
                  # Play the sound when the button is clicked
                elif botao2_pos.collidepoint(event.pos):
                    janela4()
                  # Play the sound when the button is clicked

        pygame.display.update()


def fase02():
    janela = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("fase02.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))
    global ponto
    ponto = 0
    global acerto2 
    acerto2 = 0
    janela.blit(imagem, (0, 0))

    botao_img = pygame.image.load("voltar.png")
    botao_pos = pygame.Rect(22,670, 490, 400)

    botao_img = pygame.transform.scale(botao_img, (220, 130))

    botao2_img = pygame.image.load("pro02.png")
    botao2_pos = pygame.Rect(1180,670, 240, 140)

    botao2_img = pygame.transform.scale(botao2_img, (250, 142))

    janela.blit(botao_img, botao_pos)
    janela.blit(botao2_img, botao2_pos)
    levelup.play()



    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_pos.collidepoint(event.pos):
                    janela100()
                  # Play the sound when the button is clicked
                elif botao2_pos.collidepoint(event.pos):
                    janela14()
                  # Play the sound when the button is clicked

        pygame.display.update()

def fase03():
    janela = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")
    global ponto
    ponto = 0
    global acerto3
    acerto3 = 0
    imagem = pygame.image.load("fase03.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela.blit(imagem, (0, 0))

    botao_img = pygame.image.load("voltar.png")
    botao_pos = pygame.Rect(22,670, 490, 400)

    botao_img = pygame.transform.scale(botao_img, (220, 130))

    botao2_img = pygame.image.load("pro02.png")
    botao2_pos = pygame.Rect(1180,670, 240, 140)

    botao2_img = pygame.transform.scale(botao2_img, (250, 142))

    janela.blit(botao_img, botao_pos)
    janela.blit(botao2_img, botao2_pos)
    levelup.play()



    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_pos.collidepoint(event.pos):
                    janela100()
                  # Play the sound when the button is clicked
                elif botao2_pos.collidepoint(event.pos):
                    janela19()
                  # Play the sound when the button is clicked

        pygame.display.update()

def fase04():
    janela = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")
    global ponto
    ponto = 0
    global acerto4 
    acerto4 = 0
    imagem = pygame.image.load("fase04.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela.blit(imagem, (0, 0))

    botao_img = pygame.image.load("voltar.png")
    botao_pos = pygame.Rect(22,670, 490, 400)

    botao_img = pygame.transform.scale(botao_img, (220, 130))

    botao2_img = pygame.image.load("pro02.png")
    botao2_pos = pygame.Rect(1180,670, 240, 140)

    botao2_img = pygame.transform.scale(botao2_img, (250, 142))

    janela.blit(botao_img, botao_pos)
    janela.blit(botao2_img, botao2_pos)
    levelup.play()



    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_pos.collidepoint(event.pos):
                    janela100()
                  # Play the sound when the button is clicked
                elif botao2_pos.collidepoint(event.pos):
                    janela24()
                  # Play the sound when the button is clicked

        pygame.display.update()

def fase05():
    janela = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")
    global ponto
    ponto = 0
    global acerto5
    acerto5 = 0
    imagem = pygame.image.load("fase05.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela.blit(imagem, (0, 0))

    botao_img = pygame.image.load("voltar.png")
    botao_pos = pygame.Rect(22,670, 490, 400)

    botao_img = pygame.transform.scale(botao_img, (220, 130))

    botao2_img = pygame.image.load("pro02.png")
    botao2_pos = pygame.Rect(1180,670, 240, 140)

    botao2_img = pygame.transform.scale(botao2_img, (250, 142))

    janela.blit(botao_img, botao_pos)
    janela.blit(botao2_img, botao2_pos)
    levelup.play()



    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_pos.collidepoint(event.pos):
                    janela100()
                  # Play the sound when the button is clicked
                elif botao2_pos.collidepoint(event.pos):
                    janela28()
                  # Play the sound when the button is clicked

        pygame.display.update()



def janela7():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO02.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))


    botaoA_img = pygame.image.load("alternativa21.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)
    acerto.play()


    botaoB_img = pygame.image.load("alternativa22.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)


    botaoC_img = pygame.image.load("alternativa23.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)


    botaoD_img = pygame.image.load("alternativa24.png")
    botaoD_pos = pygame.Rect(5, 580, 740, 134)

    global ponto
    global acerto1
    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))
    print(ponto)



    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                    
            
                elif botaoB_pos.collidepoint(event.pos):
                    erro()
                    

                elif botaoC_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto1 += 1
                    janela8()

                    #acerto

                elif botaoD_pos.collidepoint(event.pos):
                    erro()
                



        pygame.display.update()


def janela8():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO03.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto1
    botaoA_img = pygame.image.load("alternativa31.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)


    botaoB_img = pygame.image.load("alternativa32.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)
    

    botaoC_img = pygame.image.load("alternativa33.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)


    botaoD_img = pygame.image.load("alternativa34.png")
    botaoD_pos = pygame.Rect(5, 580, 740, 134)
    

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                    
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()
                    

                elif botaoC_pos.collidepoint(event.pos):
                    erro()
                

                elif botaoD_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto1 += 1
                    janela9()
                    #acerto



        pygame.display.update()

def janela9():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO04.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))


    botaoA_img = pygame.image.load("alternativa43.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)


    botaoB_img = pygame.image.load("alternativa42.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)
    

    botaoC_img = pygame.image.load("alternativa41.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)
    

    botaoD_img = pygame.image.load("alternativa44.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))

    global ponto
    global acerto1


    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto1 += 1
                    janela10()
                    #acerto
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()
                

                elif botaoC_pos.collidepoint(event.pos):
                    erro()
                    

                elif botaoD_pos.collidepoint(event.pos):
                    erro()
                



        pygame.display.update()



def janela10():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO05.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))
    global ponto
    global acerto1

    botaoA_img = pygame.image.load("alternativa52.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)


    botaoB_img = pygame.image.load("alternativa51.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)


    botaoC_img = pygame.image.load("alternativa53.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)
    

    botaoD_img = pygame.image.load("alternativa54.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                
                elif botaoB_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto1 += 1
                    janela11()

                    #acerto
                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()


def janela11():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO06.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))
    global ponto
    global acerto1

    botaoA_img = pygame.image.load("alternativa61.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa62.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa63.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa64.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto1 += 1
                    janela12()
                    #acerto
                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()

def janela12():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO07.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto1
    botaoA_img = pygame.image.load("alternativa71.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa72.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa73.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa74.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto1 += 1
                    janela13()
                    #acerto
                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()

def janela13():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO08.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))
    global ponto
    global acerto1

    botaoA_img = pygame.image.load("alternativa81.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa82.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa83.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa84.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                
                elif botaoB_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto1 += 1
                    fase02()
                

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()


def janela14():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO21.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto2
    botaoA_img = pygame.image.load("alternativa211.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa212.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa213.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa214.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                
                elif botaoB_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto2 += 1
                    janela15()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()


def janela15():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO22.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto2
    botaoA_img = pygame.image.load("alternativa221.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa222.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa223.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa224.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                
                elif botaoB_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto2 += 1
                    janela16()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()


def janela16():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO23.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))
    global ponto
    global acerto2

    botaoA_img = pygame.image.load("alternativa231.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa232.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa233.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa234.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                
                elif botaoB_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto2 += 1
                    janela17()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()

def janela17():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO24.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto2
    botaoA_img = pygame.image.load("alternativa241.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa242.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa243.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa244.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto2 += 1
                    janela18()
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()

def janela18():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO25.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto2
    botaoA_img = pygame.image.load("alternativa251.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa252.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa253.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa254.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto2 += 1
                    fase03()
                
                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()



def janela19():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO31.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto3
    botaoA_img = pygame.image.load("alternativa311.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa312.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa313.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa314.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                    
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto3 += 1
                    janela20()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()


def janela20():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO32.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto3
    botaoA_img = pygame.image.load("alternativa321.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa322.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa323.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa324.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto3 += 1
                    janela21()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()

def janela21():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO33.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))
    global ponto
    global acerto3

    botaoA_img = pygame.image.load("alternativa331.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa332.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa333.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa334.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto3 += 1
                    janela22()



        pygame.display.update()


def janela22():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO34.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto3
    botaoA_img = pygame.image.load("alternativa341.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa342.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa343.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa344.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoD_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto3 += 1
                    janela23()
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoA_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()


def janela23():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO35.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto3
    botaoA_img = pygame.image.load("alternativa351.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa352.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa353.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa354.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoC_pos.collidepoint(event.pos):
                    erro()
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoA_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto3 += 1
                    fase04()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()

def janela24():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO41.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto4
    botaoA_img = pygame.image.load("alternativa411.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa412.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa413.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa414.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoB_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto4 += 1
                    janela25()
                
                elif botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()

def janela25():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO42.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))
    global ponto
    global acerto4

    botaoA_img = pygame.image.load("alternativa421.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa422.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa423.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa424.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto4 += 1
                    janela26()
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()


def janela26():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO43.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto4
    botaoA_img = pygame.image.load("alternativa431.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa432.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa433.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa434.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoB_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto4 += 1
                    janela27()
                
                elif botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()


def janela27():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO44.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto4
    botaoA_img = pygame.image.load("alternativa441.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa442.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa443.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa444.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto4 += 1
                    fase05()
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()

def janela28():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO51.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto5
    botaoA_img = pygame.image.load("alternativa511.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa512.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa513.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa514.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                
                elif botaoB_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto5 += 1
                    janela29()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()


def janela29():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO52.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))
    global ponto
    global acerto5

    botaoA_img = pygame.image.load("alternativa521.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa522.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa523.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa524.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoB_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto5 += 1
                    janela30()
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()


def janela30():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO53.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto5
    botaoA_img = pygame.image.load("alternativa531.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa532.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa533.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa534.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoB_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto5 += 1
                    janela31()
                
                elif botaoA_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()

def janela31():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO54.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))

    global ponto
    global acerto5
    botaoA_img = pygame.image.load("alternativa541.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa542.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa543.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa544.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    erro()
                
                elif botaoC_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto5 += 1
                    janela32()

                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()

def janela32():

    janela2 = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Quiz Python")

    imagem = pygame.image.load("QUESTAO55.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela2.blit(imagem, (0, 0))
    global ponto
    global acerto5

    botaoA_img = pygame.image.load("alternativa551.png")
    botaoA_pos = pygame.Rect(710, 173,740,134)

    botaoB_img = pygame.image.load("alternativa552.png")
    botaoB_pos = pygame.Rect(723, 378, 740, 134)

    botaoC_img = pygame.image.load("alternativa553.png")
    botaoC_pos = pygame.Rect(723, 580, 740, 134)

    botaoD_img = pygame.image.load("alternativa554.png")
    botaoD_pos = pygame.Rect(2, 580, 740, 134)

    
    botaoA_img = pygame.transform.scale(botaoA_img, (740, 134))
    botaoB_img = pygame.transform.scale(botaoB_img, (740, 134))
    botaoC_img = pygame.transform.scale(botaoC_img, (740, 134))
    botaoD_img = pygame.transform.scale(botaoD_img, (740, 134))




    
    janela2.blit(botaoA_img, botaoA_pos)
    janela2.blit(botaoB_img, botaoB_pos)
    janela2.blit(botaoC_img, botaoC_pos)
    janela2.blit(botaoD_img, botaoD_pos)
    acerto.play()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                             
                if botaoA_pos.collidepoint(event.pos):
                    ponto += 10
                    acerto5 += 1
                    telafinal()
                
                elif botaoB_pos.collidepoint(event.pos):
                    erro()

                elif botaoC_pos.collidepoint(event.pos):
                    erro()

                elif botaoD_pos.collidepoint(event.pos):
                    erro()



        pygame.display.update()



def janela_de_creditos():
    janela_creditos = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Janela de Créditos")

    imagem = pygame.image.load("16.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela_creditos.blit(imagem, (0, 0))

    botao_img = pygame.image.load("sair01.png")
    botao_pos = pygame.Rect(1175,680, 250, 155)

    botao_img = pygame.transform.scale(botao_img, (250, 155))

    janela_creditos.blit(botao_img, botao_pos)


    botao2_img = pygame.image.load("invisible.png")
    botao2_pos = pygame.Rect(668,600, 280, 155)

    botao2_img = pygame.transform.scale(botao2_img, (280, 155))

    janela_creditos.blit(botao2_img, botao2_pos)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_pos.collidepoint(event.pos):
                    janela1()
                elif botao2_pos.collidepoint(event.pos):
                    janela66660()



        pygame.display.update()


def janela66660():
    janela_creditos = pygame.display.set_mode((Largura, Altura))
    pygame.display.set_caption("Janela de Créditos")

    imagem = pygame.image.load("17.png")
    imagem = pygame.transform.scale(imagem, (Largura, Altura))

    janela_creditos.blit(imagem, (0, 0))

    botao_img = pygame.image.load("sair01.png")
    botao_pos = pygame.Rect(1175,680, 250, 155)

    botao_img = pygame.transform.scale(botao_img, (250, 155))

    janela_creditos.blit(botao_img, botao_pos)


    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_pos.collidepoint(event.pos):
                    janela1()

        pygame.display.update()
janela1()
pygame.display.update()